export const pss_seg7_texture_07000000 = []

export const pss_seg7_texture_07000800 = []

export const pss_seg7_texture_07001000 = []
